CREATE DATABASE biblioteca;
use biblioteca;
CREATE TABLE cad_livro (
  cod_livro VARCHAR(50) NOT NULL,
  nome_livro varchar(150) NOT NULL,
  pag_livro INT NOT NULL,
  idioma_livro VARCHAR(50),
  data_livro VARCHAR(12),
  editora_livro VARCHAR(50) NOT NULL,
  desc_livro TEXT NOT NULL  
  )ENGINE=INNODB;
  
select * from cad_livro;
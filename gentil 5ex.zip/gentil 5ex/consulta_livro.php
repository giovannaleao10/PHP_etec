<?php

include_once("conecta_mysql.inc");

$pesquisa = $_POST['nome_livro'];
$pesquisa1 = $_POST['cod_livro'];

?>

<html>
<head>
    <title> Consulta Livros </title>
</head>
<body>
    <table aligh="center" border="1" style='width:50%'>
    <tr>
        <th>Codigo do livro</th>
        <th>Nome do Livro</th>
        <th>Descrição do Livro</th>
    </tr>
<?php
$sql = "SELECT * FROM cad_livro WHERE nome_livro LIKE '%$pesquisa%' OR cod_livro LIKE '%$pesquisa1%'";

$resultado = mysqli_query($conexao,$sql) or die("Erro ao retonar dado");

while ($registro = mysqli_fetch_array($resultado))

{
    $nome_livro = $registro['nome_livro'];
    $cod_livro = $registro['cod_livro'];
    $desc_livro = $registro['desc_livro'];
    echo "<tr>";
    echo "<td>".$cod_livro."</td>";
    echo "<td>".$nome_livro."</td>";
    echo "<td>".$desc_livro."</td>";
    echo "</tr>";
}
mysqli_close($conexao);
echo "</table>";
?>

</body>
</html>
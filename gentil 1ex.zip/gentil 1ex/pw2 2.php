<?php

$nome       =$_POST['nome'];
$cod        =$_POST['cod'];
$pag     =$_POST['pag'];
$idioma       =$_POST['idioma'];
$publi        =$_POST['publi'];
$edit     =$_POST['edit'];
$desc  =$_POST['desc'];
$erro       =0;

if (empty($nome) OR strstr($nome,' ')==false){
    echo "Favor digitar seu nome.<br>";
    $erro = 1
}

if (empty($cod)){
    echo "Favor digitar seu código corretamente.<br>";
    $erro = 1;
}

if (empty($pag)){
    echo "Favor digitar o número de páginas.<br>";
    $erro = 1;
}

if (empty($idioma)){
    echo "Favor digitar o idioma do livro desejado.<br>";
    $erro = 1;
}

if (empty($publi)){
    echo "Favor digitar a data de publicação.<br>";
    $erro = 1;
}

if (empty($edit) <8 || strstr($edit,' ')==false) {
    echo "Favor digitar a editora.<br>";
    $erro = 1;
}

if (empty($desc)){
    echo "Digite uma descrição .<br>";
    $erro = 1;
}

if ($erro == 0){
    echo "Todos os dados foram digitados corretamente.<br>";
    include 'insere.inc';
}

?>
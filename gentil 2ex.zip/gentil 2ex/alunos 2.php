<?php

$nome       =$_POST['nome'];
$cpf        =$_POST['cpf'];
$email      =$_POST['email'];
$curso      =$_POST['curso'];
$serie      =$_POST['serie'];
$horario      =$_POST['horario'];
$dados_adicionais  =$_POST['dados_adicionais'];
$erro       =0;

if (empty($nome) OR strstr($nome,' ')==false){
    echo "Favor digitar seu nome corretamente.<br>";
    $erro = 1
}

if (empty($cpf)){
    echo "Favor digitar seu cpf corretamente.<br>";
    $erro = 1;
}

if (empty($email) <8 || strstr($email,'@')==false) {
    echo "Favor digitar seu email corretamente.<br>";
    $erro = 1;
}

if (empty($curso) <8 || strstr($curso,'')==false) {
    echo "Favor digitar seu curso.<br>";
    $erro = 1;
}

if (empty($serie) <8 || strstr($serie,'')==false) {
    echo "Favor digitar sua serie.<br>";
    $erro = 1;
}

if (empty($horario) <8 || strstr($horario,'')==false) {
    echo "Favor digitar seu periodo.<br>";
    $erro = 1;
}

if (empty($dados_adicionais)){
    echo "Digite um dado adicional.<br>";
    $erro = 1;
}

if ($erro == 0){
    echo "Todos os dados foram digitados corretamente.<br>";
}

?>